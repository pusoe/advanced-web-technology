from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json

from .models import Task, TaskCategory


@csrf_exempt
def create(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        title = data.get('title', '')
        description = data.get('description', '')
        status = data.get('status', '')

        if title and status:
            task = Task.objects.create(title=title, description=description, status=status)
            return JsonResponse(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status},
                status=201)
        else:
            return JsonResponse({'error': 'Title and status are required.'}, status=400)
    else:
        return JsonResponse({'error': 'Method not allowed.'}, status=405)


@csrf_exempt
def get(request):
    if request.method == 'GET':
        tasks = Task.objects.all()
        task_list = []
        for task in tasks:
            task_list.append(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status})
        return JsonResponse(task_list, safe=False)


@csrf_exempt
def getbytaskid(request, task_id):
    if request.method == 'GET':
        try:
            task = Task.objects.get(id=task_id)
            return JsonResponse(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status})
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)


@csrf_exempt
def update(request, task_id):
    if request.method == 'PUT':
        try:
            task = Task.objects.get(id=task_id)
            data = json.loads(request.body)
            title = data.get('title', task.title)
            description = data.get('description', task.description)
            status = data.get('status', task.status)

            task.title = title
            task.description = description
            task.status = status
            task.save()

            return JsonResponse(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status})
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)


@csrf_exempt
def delete(request, task_id):
    if request.method == 'DELETE':
        try:
            task = Task.objects.get(id=task_id)
            task.delete()
            return JsonResponse({'message': 'Task deleted successfully.'}, status=204)
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)


@csrf_exempt
def createcategory(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        name = data.get('name')

        if name:
            category = TaskCategory.objects.create(name=name)
            return JsonResponse({'id': category.id, 'name': category.name}, status=201)
        else:
            return JsonResponse({'error': 'Name is required.'}, status=400)
    else:
        return JsonResponse({'error': 'Method not allowed.'}, status=405)


@csrf_exempt
def getcategories(request):
    if request.method == 'GET':
        categories = TaskCategory.objects.all()
        category_list = [{'id': category.id, 'name': category.name} for category in categories]
        return JsonResponse(category_list, safe=False)


@csrf_exempt
def getcategorybyid(request, category_id):
    if request.method == 'GET':
        try:
            category = TaskCategory.objects.get(id=category_id)
            return JsonResponse({'id': category.id, 'name': category.name})
        except TaskCategory.DoesNotExist:
            return JsonResponse({'error': 'Category not found.'}, status=404)


@csrf_exempt
def updatecategory(request, category_id):
    if request.method == 'PUT':
        try:
            category = TaskCategory.objects.get(id=category_id)
            data = json.loads(request.body)
            name = data.get('name', category.name)
            category.name = name
            category.save()
            return JsonResponse({'id': category.id, 'name': category.name})
        except TaskCategory.DoesNotExist:
            return JsonResponse({'error': 'Category not found.'}, status=404)


@csrf_exempt
def deleteCategory(request, category_id):
    if request.method == 'DELETE':
        try:
            category = TaskCategory.objects.get(id=category_id)
            category.delete()
            return JsonResponse({'message': 'Category deleted successfully.'}, status=204)
        except TaskCategory.DoesNotExist:
            return JsonResponse({'error': 'Category not found.'}, status=404)

    return JsonResponse({'error': 'Method not allowed.'}, status=405)


@csrf_exempt
def associatetaskwithcategory(request, task_id, category_id):
    if request.method == 'PUT':
        try:
            task = Task.objects.get(id=task_id)
            category = TaskCategory.objects.get(id=category_id)
            task.category = category
            task.save()
            return HttpResponse('Task associated with the category successfully.', status=200)
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)
        except TaskCategory.DoesNotExist:
            return JsonResponse({'error': 'Category not found.'}, status=404)

    return HttpResponse('Method not allowed.', status=405)


@csrf_exempt
def filtertasksbycategory(request, category_id):
    if request.method == 'GET':
        try:
            category = TaskCategory.objects.get(id=category_id)
            tasks = Task.objects.filter(category=category)
            task_list = [{'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status}
                         for task in tasks]
            return JsonResponse(task_list, safe=False)
        except TaskCategory.DoesNotExist:
            return JsonResponse({'error': 'Category not found.'}, status=404)


@csrf_exempt
def uploadattachment(request, task_id):
    if request.method == 'POST':
        try:
            task = Task.objects.get(id=task_id)
            attachment = request.FILES.get('attachment')
            if attachment:
                #  (e.g., file type, size)
                valid_extensions = ['.pdf', '.doc', '.docx', '.txt']
                if not attachment.name.lower().endswith(tuple(valid_extensions)):
                    return JsonResponse({'error': 'Invalid file type. Only PDF and Word documents are allowed.'},
                                        status=400)

                # maximum file size ( # 5MB)
                max_file_size = 5 * 1024 * 1024
                if attachment.size > max_file_size:
                    return JsonResponse({'error': 'File size exceeds the allowed limit.'}, status=400)

                # Process and store the file
                task.attachment = attachment
                task.save()
                return JsonResponse({'message': 'File uploaded successfully.'}, status=200)
            else:
                return JsonResponse({'error': 'No file provided.'}, status=400)
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)


@csrf_exempt
def downloadattachment(request, task_id):
    if request.method == 'GET':
        try:
            task = Task.objects.get(id=task_id)
            if task.attachment:
                file_path = task.attachment.path
                with open(file_path, 'rb') as file:
                    response = HttpResponse(file.read(), content_type='application/octet-stream')
                    response['Content-Disposition'] = 'attachment; filename=' + task.attachment.name
                    return JsonResponse({'message': 'File downloaded successfully.'}, status=200)
            else:
                return JsonResponse({'error': 'Task does not have an attachment.'}, status=404)
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)
