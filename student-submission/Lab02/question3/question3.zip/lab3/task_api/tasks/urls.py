from . import views
from django.urls import path

from .views import createcategory, getcategories, getcategorybyid, updatecategory, deleteCategory, \
    associatetaskwithcategory, filtertasksbycategory, create, get, getbytaskid, update, delete, uploadattachment, \
    downloadattachment

app_name = 'tasks'

urlpatterns = [
    # question1
    path('taskcreate', create),
    path('taskshow', get),
    path('taskget/<int:task_id>', getbytaskid),
    path('taskupdate/<int:task_id>', update),
    path('taskdelete/<int:task_id>', delete),
    # question2
    path('createcategory', createcategory),
    path('getcategories', getcategories),
    path('getcategorybyid/<int:category_id>', getcategorybyid),
    path('updatecategory/<int:category_id>', updatecategory),
    path('deletecategory/<int:category_id>', deleteCategory),
    path('tasks/<int:task_id>/category/<int:category_id>', associatetaskwithcategory),
    path('tasks/category/<int:category_id>', filtertasksbycategory),
    # Question3
    path('tasks/<int:task_id>/uploadattachment', uploadattachment),
    path('tasks/<int:task_id>/downloadattachment', downloadattachment),
]
