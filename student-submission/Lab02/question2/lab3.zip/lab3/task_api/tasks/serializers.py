from rest_framework import serializers
from task_api.tasks.models import Task, TaskCategory


class TaskSerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(queryset=TaskCategory.objects.all(), allow_null=True)

    class Meta:
        model = Task
        fields = '__all__'
