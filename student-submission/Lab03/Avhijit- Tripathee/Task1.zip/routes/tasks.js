const express = require('express')
const router = express.Router()
const Task = require('../models/task')


//Getting All
router.get('/', async(req, res) =>{
    try{
        const tasks = await Task.find()
        res.send(tasks)
    }
    catch(err){
        res.status(500).json({message : err.message})
    }
})
//Getting One
router.get('/:id', getTask,  (req, res) =>{
    res.send(res.task.description)
})
//Creating One
router.post('/',  async(req, res) =>{
    const task = new Task({
        title: req.body.title,
        description: req.body.description,
        status: req.body.status
    })
    try{
        const newTask = await task.save()
        res.status(201).json(newTask)
    }
    catch (err){
        res.status(400).json({message: err.message})

    }
   
})

router.patch('/:id', getTask, async(req, res) =>{
    if(req.body.name != null){
        res.task.name = req.body.name
    }
    if(req.body.description != null){
        res.task.description = req.body.description
    }
    try{
        const updatedDescription = await res.task.save()
        res.json(updatedDescription)
    }
    catch(err){
        res.status(400).json({message : err.message})
    }
})


//Deleting One
router.delete('/:id',getTask, async (req, res) =>{
    try {
        await res.task.deleteOne();
        res.json({message: "task Deleted"})
    }
    catch(err) {
        res.status(500).json({message : err.message})
    }
})

async function getTask(req, res, next){
    let task
    try{
        task = await Task.findById(req.params.id)
        if(task == null){
            return res.status(404).json({ message : "Cannot find Task"})
        }
    }catch(err){
        return res.status(500).json({message : err.message})
    }

    res.task = task
    next()
}
module.exports = router