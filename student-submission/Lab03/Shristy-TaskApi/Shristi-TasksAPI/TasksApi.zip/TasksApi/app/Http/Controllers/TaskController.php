<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tasks;

class TaskController extends Controller
{
    public function index(){
        $tasks = Tasks::all();
        return response()->json($tasks);
    }

    public function store(Request $request){
        $task = new Tasks;
        $task->title = $request->title;
        $task->description = $request->description;
        $task->status = $request->status;
        $task->save();
        return response()->json([
            "message"=>"Task Added."
        ], 201);
    }

    public function show($id) {
        $task = Tasks::find($id);
        if(!empty($task)){
            return response()->json($task);
        }else{
            return response()->json([
                "message" => "Task not found"
            ], 404);
        }
    }


    public function update(Request $request, $id) {

        if(Tasks::where('id',$id)->exists()){
            $task = Tasks::find($id);
            $task->title = is_null($request->title) ? $task->title : $request->title;
            $task->description = is_null($request->description) ? $task->description : $request->description;
            $task->status = is_null($request->status) ? $task->status : $request->status;
            $task->save();
            return response()->json([
                "message"=>"Task Updated."
            ], 202);
        }else{
            return response()->json([
                "message" => "Task not found"
            ], 404);
        }
    }

    public function destroy(Request $request, $id) {

        if(Tasks::where('id',$id)->exists()){
            $task = Tasks::find($id);
            $task->delete();
            
            return response()->json([
                "message"=>"Task Deleted."
            ], 202);
        }else{
            return response()->json([
                "message" => "Task not found"
            ], 404);
        }
    }
}
