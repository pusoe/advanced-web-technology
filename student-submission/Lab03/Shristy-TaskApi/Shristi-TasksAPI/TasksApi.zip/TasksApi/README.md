Simple REST API for task management
