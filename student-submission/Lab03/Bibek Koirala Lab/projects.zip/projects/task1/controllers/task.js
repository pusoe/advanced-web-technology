export const getAll = async (req, res) => {
  try {
    const tasks = await Task.find();
    res.send(tasks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const getOne = (req, res) => {
  res.send(res.task.description);
};

export const createOne = async (req, res) => {
  const task = new Task({
    title: req.body.title,
    description: req.body.description,
    status: req.body.status,
  });
  try {
    const newTask = await task.save();
    res.status(201).json(newTask);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

export const patchOne = async (req, res) => {
  if (req.body.name != null) {
    res.task.name = req.body.name;
  }
  if (req.body.description != null) {
    res.task.description = req.body.description;
  }
  try {
    const updatedDescription = await res.task.save();
    res.json(updatedDescription);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

export const deleteOne = async (req, res) => {
  try {
    await res.task.remove();
    res.json({ message: "task Deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
