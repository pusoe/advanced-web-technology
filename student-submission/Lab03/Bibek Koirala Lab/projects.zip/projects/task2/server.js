// server.js
const express = require("express");
const mongoose = require("mongoose");

// Import route files
const tasksRouter = require("./routes/tasks");
const categoriesRouter = require("./routes/categories");

// Initialize Express app
const app = express();
const port = 3000;

// Connect to MongoDB

const uri = `mongodb+srv://admin:1234567890@cluster0.p2qsvql.mongodb.net/?retryWrites=true&w=majority`;
mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Handle MongoDB connection events
const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => {
  console.log("Connected to MongoDB");
});

// Configure routes
app.use(express.json());
app.use("/tasks", tasksRouter);
app.use("/categories", categoriesRouter);

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
