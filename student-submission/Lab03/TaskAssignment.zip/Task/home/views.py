from .models import Category,Tasks
from rest_framework import generics
from home.serializers import CatagorySerializers ,TasksSerializers
from rest_framework import generics


class Catagory(generics.RetrieveUpdateDestroyAPIView):
    queryset = Category.objects.all()
    serializer_class = CatagorySerializers

class CatagoryList(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CatagorySerializers
    
class Task(generics.RetrieveUpdateDestroyAPIView):
    queryset = Tasks.objects.all()
    serializer_class = TasksSerializers

class TasksList(generics.ListCreateAPIView):
    queryset = Tasks.objects.all()
    serializer_class = TasksSerializers
