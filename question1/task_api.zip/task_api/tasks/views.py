from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from .models import Task
import json


@csrf_exempt
def create(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        title = data.get('title', '')
        description = data.get('description', '')
        status = data.get('status', '')

        if title and status:
            task = Task.objects.create(title=title, description=description, status=status)
            return JsonResponse(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status},
                status=201)
        else:
            return JsonResponse({'error': 'Title and status are required.'}, status=400)
    else:
        return JsonResponse({'error': 'Method not allowed.'}, status=405)


@csrf_exempt
def get(request):
    if request.method == 'GET':
        tasks = Task.objects.all()
        task_list = []
        for task in tasks:
            task_list.append(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status})
        return JsonResponse(task_list, safe=False)


@csrf_exempt
def getbytaskid(request, task_id):
    if request.method == 'GET':
        try:
            task = Task.objects.get(id=task_id)
            return JsonResponse(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status})
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)


@csrf_exempt
def update(request, task_id):
    if request.method == 'PUT':
        try:
            task = Task.objects.get(id=task_id)
            data = json.loads(request.body)
            title = data.get('title', task.title)
            description = data.get('description', task.description)
            status = data.get('status', task.status)

            task.title = title
            task.description = description
            task.status = status
            task.save()

            return JsonResponse(
                {'id': task.id, 'title': task.title, 'description': task.description, 'status': task.status})
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)


@csrf_exempt
def delete(request, task_id):
    if request.method == 'DELETE':
        try:
            task = Task.objects.get(id=task_id)
            task.delete()
            return JsonResponse({'message': 'Task deleted successfully.'}, status=204)
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found.'}, status=404)