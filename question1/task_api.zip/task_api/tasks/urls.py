from . import views
from django.urls import path

from .views import create, get, getbytaskid, update, delete

app_name = 'tasks'

urlpatterns = [
    path('taskcreate', create),
    path('taskshow', get),
    path('taskget/<int:task_id>/', getbytaskid),
    path('taskupdate/<int:task_id>/', update),
    path('taskdelete/<int:task_id>/', delete),
]
