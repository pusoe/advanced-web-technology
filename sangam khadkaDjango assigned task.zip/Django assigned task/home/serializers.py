from rest_framework import serializers
from .models import Category ,Tasks

class TasksSerializers(serializers.ModelSerializer):
    class Meta:
        model = Tasks
        fields= '__all__'

class CatagorySerializers(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields= '__all__'