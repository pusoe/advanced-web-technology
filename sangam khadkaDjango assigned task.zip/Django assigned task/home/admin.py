from django.contrib import admin
from .models import Tasks ,Category
# Register your models here.
admin.site.register(Tasks)
admin.site.register(Category)