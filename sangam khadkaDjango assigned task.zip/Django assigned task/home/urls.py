from django.conf import settings
from django.conf.urls.static import static
from .views import Catagory,CatagoryList ,TasksList, Task
from django.urls import path



urlpatterns = [
    path('catagory', CatagoryList.as_view(), name='students'),
    path('catagory/<pk>', Catagory.as_view(), name='students'),
    path('', TasksList.as_view(), name='student'),
    path('<pk>', Task.as_view(), name='student'),

    ]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT) 